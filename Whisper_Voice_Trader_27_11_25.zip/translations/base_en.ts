<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="tr_TR">
<context>
    <name>APISettingsDialog</name>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="20"/>
        <source>🔑 API Ayarları</source>
        <translation>API Settings</translation>
    </message>
    <message>
        <location filename="../ui/raw/binance_api_settings_dialog.ui" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;Binance API Anahtarları&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;Binance API Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="51"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#848e9c;&quot;&gt;API anahtarlarınız şifreli bir şekilde saklanır. Binance hesabınızdan Futures Trading izinli API anahtarları oluşturun. &lt;/span&gt;&lt;span style=&quot; font-weight:600; color:#f6465d;&quot;&gt;Asla Withdrawal iznini aktif etmeyin!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#848e9c;&quot;&gt;Your API keys are stored in an encrypted manner. Create API keys with Futures Trading permissions from your Binance account.&lt;/span&gt;&lt;span style=&quot; font-weight:600; color:#f6465d;&quot;&gt;Never activate the withdrawal permission!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="68"/>
        <source>Ortam Seçimi</source>
        <translation>Platform Selection</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="74"/>
        <source>🧪 Testnet (Test Ortamı - Tavsiye Edilir)</source>
        <translation>🧪 Testnet (Test Environment - Recommended)</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="84"/>
        <source>💰 Mainnet (Gerçek İşlemler - DİKKAT!)</source>
        <translation>💰 Mainnet (Real Transactions - ATTENTION!)</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="91"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;⚠️ İlk testlerinizi mutlaka Testnet'te yapın!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;⚠️ Be sure to run your initial tests on Testnet!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="101"/>
        <source>🔐 Master Password (Şifreleme Anahtarı)</source>
        <translation>🔐 Master Password (Encryption Key)</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="107"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;API anahtarlarınızı şifrelemek için güçlü bir şifre belirleyin. Bu şifreyi unutursanız API anahtarlarınız kurtarılamaz!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Set a strong password to encrypt your API keys. If you forget this password, your API keys cannot be recovered!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="119"/>
        <source>Şifre:</source>
        <translation>Password:</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="137"/>
        <source>Güçlü bir şifre belirleyin</source>
        <translation>Set a strong password</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="302"/>
        <source>Göster/Gizle</source>
        <translation>Show/Hide</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="305"/>
        <source>👁️</source>
        <translation>👁️</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="168"/>
        <source>Şifre Tekrar:</source>
        <translation>Re-Password:</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="184"/>
        <source>Şifreyi tekrar girin</source>
        <translation>Please enter the password again.</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="195"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Şifre Gücü:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Password Strength:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="221"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;-&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-size:9pt; color:#848e9c;&quot;&gt;-&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="233"/>
        <source>API Anahtarları</source>
        <translation>API Keys</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="245"/>
        <source>API Key:</source>
        <translation>API Key</translation>
    </message>
    <message>
        <location filename="../ui/raw/binance_api_settings_dialog.ui" line="258"/>
        <source>Binance API Key&apos;inizi buraya girin</source>
        <translation>Enter your Binance API Key here</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="265"/>
        <source>Secret Key:</source>
        <translation>Secret Key:</translation>
    </message>
    <message>
        <location filename="../ui/raw/binance_api_settings_dialog.ui" line="283"/>
        <source>Binance Secret Key&apos;inizi buraya girin</source>
        <translation>Enter your Binance Secret Key here</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="317"/>
        <source>Bağlantı Durumu</source>
        <translation>Connection Status</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="331"/>
        <source>🔴</source>
        <translation>🔴</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="338"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#848e9c;&quot;&gt;Bağlantı test edilmedi&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#848e9c;&quot;&gt;Connection not tested&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="364"/>
        <source>🔄 Bağlantıyı Test Et</source>
        <translation>🔄 Test the Connection</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="388"/>
        <source>Bağlantı test sonuçları burada görünecek...</source>
        <translation>Connection test results will appear here...</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="398"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;🔒 Güvenlik Notu: API anahtarlarınız AES-256 şifreleme ile korunur ve sadece bu bilgisayarda saklanır.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;🔒 Security Note: Your API keys are protected with AES-256 encryption and are stored only on this computer.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="432"/>
        <source>🗑️ Anahtarları Sil</source>
        <translation>🗑️ Delete Keys</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="458"/>
        <source>İptal</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="471"/>
        <source>💾 Kaydet</source>
        <translation>💾 Save</translation>
    </message>
    <message>
        <location filename="../ui/raw/bybit_api_settings_dialog.ui" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;ByBit API Anahtarları&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;ByBit API Keys&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/bybit_api_settings_dialog.ui" line="258"/>
        <source>ByBit API Key&apos;inizi buraya girin</source>
        <translation>Please enter your ByBit API key here</translation>
    </message>
    <message>
        <location filename="../ui/raw/bybit_api_settings_dialog.ui" line="283"/>
        <source>ByBit Secret Key&apos;inizi buraya girin</source>
        <translation>Please enter your ByBit Secret key here</translation>
    </message>
    <message>
        <location filename="../ui/raw/kucoin_api_settings_dialog.ui" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;KuCoin API Anahtarları&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;KuCoin API Keys&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/kucoin_api_settings_dialog.ui" line="258"/>
        <source>KuCoin API Key&apos;inizi buraya girin</source>
        <translation>Please enter your KuCoin API Key here.</translation>
    </message>
    <message>
        <location filename="../ui/raw/kucoin_api_settings_dialog.ui" line="283"/>
        <source>KuCoin Secret Key&apos;inizi buraya girin</source>
        <translation>Please enter your KuCoin Secret Key here</translation>
    </message>
    <message>
        <location filename="../ui/raw/mexc_api_settings_dialog.ui" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;MEXC API Anahtarları&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;MEXC API Keys&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/mexc_api_settings_dialog.ui" line="258"/>
        <source>MEXC API Key&apos;inizi buraya girin</source>
        <translation>Please enter your MEXC API Key here.</translation>
    </message>
    <message>
        <location filename="../ui/raw/mexc_api_settings_dialog.ui" line="283"/>
        <source>MEXC Secret Key&apos;inizi buraya girin</source>
        <translation>Please enter your MEXC Secret Key here.</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;OKX API Anahtarları&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;OKX API Keys&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="258"/>
        <source>OKX API Key&apos;inizi buraya girin</source>
        <translation>Please enter your OKX API Key here</translation>
    </message>
    <message>
        <location filename="../ui/raw/okx_api_settings_dialog.ui" line="283"/>
        <source>OKX Secret Key&apos;inizi buraya girin</source>
        <translation>Please enter your OKX Secret Key here</translation>
    </message>
</context>
<context>
    <name>CommandKeywordsDialog</name>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="14"/>
        <source>Komut Ekle</source>
        <translation>Add Command</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="20"/>
        <source>Yeni komut kelimesi ekleyin:</source>
        <translation>Add a new command word:</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="32"/>
        <source>Komut türü:</source>
        <translation>Command Type:</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="40"/>
        <source>Al (BUY)</source>
        <translation>BUY</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="45"/>
        <source>Sat (SELL)</source>
        <translation>SELL</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="50"/>
        <source>Yok say (STOP)</source>
        <translation>Ignore (STOP)</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="58"/>
        <source>Kelime:</source>
        <translation>Word:</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="65"/>
        <source>ör. longla, çık, hemen...</source>
        <translation>e.g. long, get out, immediately...</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="89"/>
        <source>Kaydet</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="../ui/raw/command_keywords_dialog.ui" line="99"/>
        <source>İptal</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>EmergencyDialog</name>
    <message>
        <location filename="../ui/raw/emergency_dialog.ui" line="26"/>
        <source>🆘 ACİL DURUM</source>
        <translation>🆘 EMERGENCY</translation>
    </message>
    <message>
        <location filename="../ui/raw/emergency_dialog.ui" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:48pt;&quot;&gt;⚠️&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:48pt;&quot;&gt;⚠️&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/emergency_dialog.ui" line="60"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#f6465d;&quot;&gt;ACİL DURUM PROTOKOLÜ&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#f6465d;&quot;&gt;EMERGENCY PROTOCOL&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/emergency_dialog.ui" line="73"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Aşağıdaki işlemler yapılacak:&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;• Tüm açık pozisyonlar kapatılacak&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;• Tüm bekleyen emirler iptal edilecek&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;• Bot durdurulacak&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;The following actions will be taken:&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;• All open positions will be closed&lt;/span&gt;&lt;/ p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;• All pending orders will be canceled&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600;&quot;&gt;• The bot will be stopped&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/emergency_dialog.ui" line="86"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600; color:#fcd535;&quot;&gt;ONAYLIYOR MUSUNUZ?&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600; color:#fcd535;&quot;&gt;DO YOU AGREE?&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/emergency_dialog.ui" line="127"/>
        <source>❌ İPTAL</source>
        <translation>❌ CANCEL</translation>
    </message>
    <message>
        <location filename="../ui/raw/emergency_dialog.ui" line="150"/>
        <source>✅ ONAYLA VE DURDUR</source>
        <translation>✅ APPROVE AND STOP</translation>
    </message>
</context>
<context>
    <name>LicenseDialog</name>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="26"/>
        <source>🔐 Lisans Yönetimi</source>
        <translation>🔐 License Management</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;🔐 Lisans Yönetimi&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#fcd535;&quot;&gt;🔐 License Management&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="60"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Whisper Voice Trader - Lisans Aktivasyon&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Whisper Voice Trader - License Activation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="74"/>
        <source>📋 Lisans Durumu</source>
        <translation>📋 License Status</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="103"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:24pt;&quot;&gt;⚠️&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:24pt;&quot;&gt;⚠️&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="113"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:600; color:#fcd535;&quot;&gt;Lisans Bulunamadı&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:600; color:#fcd535;&quot;&gt;License Not Found&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="135"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#848e9c;&quot;&gt;Programı kullanmaya devam etmek için lütfen lisans anahtarınızı girin.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#848e9c;&quot;&gt;Please enter your license key to continue using the program.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="147"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Lisans Tipi:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;License Type:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="154"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Trial (7 gün kaldı)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot;font-weight:600;&quot;&gt;Trial (7 days left)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="161"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Son Kullanma:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Expiration Date:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="168"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;2024-11-13&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;2024-11-13&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="175"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Kayıtlı:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Registered:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="182"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;-&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;-&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="197"/>
        <source>🔑 Lisans Aktivasyonu</source>
        <translation>🔑 License Activation</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="205"/>
        <source>Lisans Anahtarı:</source>
        <translation>License Key:</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="221"/>
        <source>XXXX-XXXX-XXXX-XXXX</source>
        <translation>XXXX-XXXX-XXXX-XXXX</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="228"/>
        <source>E-posta (Opsiyonel):</source>
        <translation>Email (Optional):</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="241"/>
        <source>ornek@email.com</source>
        <translation>sample@email.com</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="258"/>
        <source>Panodan yapıştır</source>
        <translation>Paste from the clipboard</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="261"/>
        <source>📋 Yapıştır</source>
        <translation>📋 Paste</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="287"/>
        <source>🔄 Lisansı Doğrula</source>
        <translation>🔄 Verify License</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="299"/>
        <source>💻 Cihaz Bilgileri</source>
        <translation>💻 Device Information</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="305"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Bu cihaza özel benzersiz kimlik. Lisans satın alırken bu ID'yi kullanın.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;This is the unique ID for this device. Use this ID when purchasing a license.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="326"/>
        <source>Hardware ID yükleniyor...</source>
        <translation>Hardware ID loading...</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="345"/>
        <source>Hardware ID&apos;yi panoya kopyala</source>
        <translation>Copy the Hardware ID to the clipboard</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="348"/>
        <source>📋 Kopyala</source>
        <translation>📋 Copy</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Cihaz Adı:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Device Nameı:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="366"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;DESKTOP-ABC123&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;DESKTOP-ABC123&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="373"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;İşletim Sistemi:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Operating System:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="380"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Windows 11&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Windows 11&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="392"/>
        <source>📝 Durum</source>
        <translation>📝 Status</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="413"/>
        <source>Lisans doğrulama sonuçları burada görünecek...</source>
        <translation>License verification results will appear here...</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="423"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Lisans anahtarınız yok mu? &lt;/span&gt;&lt;a href=&quot;#buy&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#fcd535;&quot;&gt;Hemen satın alın&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Don't have a license key? &lt;/span&gt;&lt;a href=&quot;#buy&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#fcd535;&quot;&gt;Buy now&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="460"/>
        <source>💳 Lisans Satın Al</source>
        <translation>💳 Purchase License</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="486"/>
        <source>🆓 7 Gün Trial Başlat</source>
        <translation>🆓 Start Your 7-Day Trial</translation>
    </message>
    <message>
        <location filename="../ui/raw/license_dialog.ui" line="499"/>
        <source>Kapat</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ui/raw/main_window.ui" line="26"/>
        <source>Crypto Voice Trader - Creagent Professional Trading Bot</source>
        <translation>Crypto Voice Trader - Creagent Professional Trading Bot</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="88"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600; color:#fcd535;&quot;&gt;🎤 Whisper&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600; color:#fcd535;&quot;&gt;🎤 Whisper&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="135"/>
        <source>🎙️ Pasif Mod</source>
        <translation>🎙️ Passive Mode</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="141"/>
        <source>passive</source>
        <translation>passive</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="175"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;0s&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;0s&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="224"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Trading Modu&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Trading Mode&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="236"/>
        <source>📄</source>
        <translation>📄</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="249"/>
        <source>Paper Trading: Gerçek para riski yok (ON) / Real Trading: Gerçek işlemler (OFF)</source>
        <translation>Paper Trading: No real money risk (ON) / Real Trading: Real transactions (OFF)</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="252"/>
        <source>Paper Trading</source>
        <translation>Paper Trading</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="262"/>
        <source>💰</source>
        <translation>💰</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1464"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Toplam Bakiye&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Total Balance&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1477"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:13pt; font-weight:600;&quot;&gt;000,000.00 USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:13pt; font-weight:600;&quot;&gt;000,000.00 USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1501"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Kâr/Zarar&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Profit/Loss&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1514"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:13pt; font-weight:600; color:#0ecb81;&quot;&gt;+0.00 USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:13pt; font-weight:600; color:#0ecb81;&quot;&gt;+0.00 USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1520"/>
        <source>positive</source>
        <translation>positive</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Marj Oranı&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Margin Ratio&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1554"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:13pt; font-weight:600;&quot;&gt;0.00%&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:13pt; font-weight:600;&quot;&gt;0.00%&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="300"/>
        <source>🔴 Bağlantı Yok</source>
        <translation>🔴 No Connection</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="303"/>
        <source>disconnected</source>
        <translation>disconnected</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="330"/>
        <source>Tüm pozisyonları kapat ve botu durdur (Ctrl+Shift+P)</source>
        <translation>Close all positions and stop the bot</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1760"/>
        <source>🆘 ACİL DURUM</source>
        <translation>🆘 EMERGENCY</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="355"/>
        <source>Dil Seçimi / Sprache / Language</source>
        <translation>Dil Seçimi / Sprache / Language</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="359"/>
        <source>🇹🇷 Türkçe</source>
        <translation>🇹🇷 Türkçe</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="364"/>
        <source>🇩🇪 Deutsch</source>
        <translation>🇩🇪 Deutsch</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="369"/>
        <source>🇬🇧 English</source>
        <translation>🇬🇧 English</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="383"/>
        <source>Aktif Exchange Platformu</source>
        <translation>Active Exchange Platform</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="393"/>
        <source>Binance</source>
        <translation>Binance</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="398"/>
        <source>MEXC</source>
        <translation>MEXC</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="403"/>
        <source>ByBit</source>
        <translation>ByBit</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="408"/>
        <source>OKX</source>
        <translation>OKX</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="413"/>
        <source>KuCoin</source>
        <translation>KuCoin</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="446"/>
        <source>Server'a Bağlan</source>
        <translation>Connect Server</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="449"/>
        <source>⚙️ BAĞLAN</source>
        <translation>⚙️ CONNECT</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="493"/>
        <source>Sembol Seçimi</source>
        <translation>Symbol Selection</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="514"/>
        <source>Yükleniyor...</source>
        <translation>Loading...</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="534"/>
        <source>Sembol listesini yenile</source>
        <translation>Refresh the symbol list</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="537"/>
        <source>🔄</source>
        <translation>🔄</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="565"/>
        <source>Best Ask</source>
        <translation>Best Ask</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="592"/>
        <source>Best Bid</source>
        <translation>Best Bid</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="610"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#0ecb81;&quot;&gt;000,000.00&lt;/span&gt;&lt;span style=&quot; font-size:12pt; color:#848e9c;&quot;&gt; USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#0ecb81;&quot;&gt;000,000.00&lt;/span&gt;&lt;span style=&quot; font-size:12pt; color:#848e9c;&quot;&gt; USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="623"/>
        <source>Kaldıraç</source>
        <translation>Leverage</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="631"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600; color:#fcd535;&quot;&gt;10x&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600; color:#fcd535;&quot;&gt;10x&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="664"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;1x&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;1x&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="684"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;125x&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;125x&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="700"/>
        <source>Limit</source>
        <translation>Limit</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="708"/>
        <source>Fiyat:</source>
        <translation>Price:</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="832"/>
        <source>Miktar (USDT):</source>
        <translation>Amount (USDT):</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="757"/>
        <source>Market</source>
        <translation>Market</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="790"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;⚠️ Market emri anında mevcut fiyattan gerçekleşir&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;⚠️ Market orders are executed immediately at the current price&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="801"/>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="809"/>
        <source>Stop Fiyatı:</source>
        <translation>Stop Price:</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="861"/>
        <source>Take Profit / Stop Loss</source>
        <translation>Take Profit / Stop Loss</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="875"/>
        <source>Take Profit (%):</source>
        <translation>Take Profit (%):</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="914"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="901"/>
        <source>Stop Loss (%):</source>
        <translation>Stop Loss (%):</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="929"/>
        <source>🎯 Trailing Stop Aktif</source>
        <translation>🎯 Trailing Stop Activate</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="957"/>
        <source>📈 AL / LONG</source>
        <translation>📈 BUY / LONG</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="977"/>
        <source>📉 SAT / SHORT</source>
        <translation>📉 SELL / SHORT</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="997"/>
        <source>🚪 Pozisyonu Kapat</source>
        <translation>🚪 Close Position</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1010"/>
        <source>🔄 Pozisyonu Ters Çevir</source>
        <translation>🔄 Reverse Position</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1035"/>
        <source>🎤 Sesli Emir</source>
        <translation>🎤 Voice Command</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1048"/>
        <source>⚙️ Komut Ekle</source>
        <translation>⚙️ Add Command</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1061"/>
        <source>❌ BAĞLANTIYI SONLANDIR</source>
        <translation>❌ TERMINATE CONNECTION</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1102"/>
        <source>Fiyat Grafiği</source>
        <translation>Price Chart</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1120"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:14pt; color:#848e9c;&quot;&gt;📊 Grafik Yüklenecek (ChartWidget Promoted)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:14pt; color:#848e9c;&quot;&gt;📊 Chart Loading (ChartWidget Promoted)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1140"/>
        <source>Açık Pozisyonlar</source>
        <translation>Open Positions</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1277"/>
        <source>Sembol</source>
        <translation>Symbol</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1282"/>
        <source>Yön</source>
        <translation>Direction</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1292"/>
        <source>Miktar</source>
        <translation>Amount</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1168"/>
        <source>Giriş Fiyatı</source>
        <translation>Entry Price</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1173"/>
        <source>Mevcut Fiyat</source>
        <translation>Current Price</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1302"/>
        <source>Kâr/Zarar</source>
        <translation>Profit/Loss</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1183"/>
        <source>Kâr/Zarar %</source>
        <translation>Profit/Loss %</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1188"/>
        <source>Likitasyon</source>
        <translation>Liquidation</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1250"/>
        <source>İşlemler</source>
        <translation>Processes</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1202"/>
        <source>Açık Emirler</source>
        <translation>Open Orders</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1220"/>
        <source>Tip</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1287"/>
        <source>Fiyat</source>
        <translation>Price</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1240"/>
        <source>Dolum</source>
        <translation>Filling</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1272"/>
        <source>Zaman</source>
        <translation>Time</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1259"/>
        <source>İşlem Geçmişi</source>
        <translation>Transaction History</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1297"/>
        <source>Komisyon</source>
        <translation>Commission</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1307"/>
        <source>Durum</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1350"/>
        <source>Emir Defteri</source>
        <translation>Order Book</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1365"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:12pt; color:#848e9c;&quot;&gt;📖 Emir Defteri&lt;br/&gt;(OrderBookWidget Promoted)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:12pt; color:#848e9c;&quot;&gt;📖 Order Book&lt;br/&gt;(OrderBookWidget Promoted)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1381"/>
        <source>Hızlı Bilgi</source>
        <translation>Quick Info</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1389"/>
        <source>24s Değişim:</source>
        <translation>24s Change:</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1396"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#0ecb81;&quot;&gt;+3.45%&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#0ecb81;&quot;&gt;+3.45%&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1403"/>
        <source>24s Hacim:</source>
        <translation>24s Volume:</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1410"/>
        <source>1.2B USDT</source>
        <translation>1.2B USDT</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1417"/>
        <source>24s En Yüksek:</source>
        <translation>24s High:</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1424"/>
        <source>68,200.00</source>
        <translation>68,200.00</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1431"/>
        <source>24s En Düşük:</source>
        <translation>24s Low:</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1438"/>
        <source>65,100.00</source>
        <translation>65,100.00</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1596"/>
        <source>Dosya</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1605"/>
        <source>Görünüm</source>
        <translation>Appearance</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1612"/>
        <source>Raporlar</source>
        <translation>Reports</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1620"/>
        <source>🔐 Lisans</source>
        <translation>🔐 License</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1630"/>
        <source>Yardım</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1663"/>
        <source>Lisans durumu - Detaylar için tıklayın</source>
        <translation>License status - Click for details</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1666"/>
        <source>🔓 Lisanssız</source>
        <translation>🔓 Unlicensed</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1672"/>
        <source>🔑 API Ayarları</source>
        <translation>🔑 API Settings</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1675"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1680"/>
        <source>⚙️ Tercihler</source>
        <translation>⚙️ Preferences</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1683"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1688"/>
        <source>🚪 Çıkış</source>
        <translation>🚪 Exit</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1691"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1702"/>
        <source>📊 Grafiği Göster/Gizle</source>
        <translation>📊 Show/Hide Chart</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1705"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1716"/>
        <source>📖 Emir Defterini Göster/Gizle</source>
        <translation>📖 Show/Hide Order Book</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1719"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1724"/>
        <source>📅 Günlük Rapor</source>
        <translation>📅 Daily Report</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1729"/>
        <source>📊 Haftalık Rapor</source>
        <translation>📊 Weekly Report</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1734"/>
        <source>📈 Aylık Rapor</source>
        <translation>📈 Aylık Rapor</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1739"/>
        <source>📖 Kullanıcı Rehberi</source>
        <translation>📖 User Guide</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1742"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1747"/>
        <source>🎤 Sesli Komutlar</source>
        <translation>🎤 Voice Commands</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1750"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1755"/>
        <source>ℹ️ Hakkında</source>
        <translation>ℹ️ About</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1763"/>
        <source>Tüm pozisyonları kapat ve botu durdur</source>
        <translation>Close all positions and stop the bot</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1766"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1771"/>
        <source>🔐 Lisans Yönetimi</source>
        <translation>🔐 License Management</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1774"/>
        <source>Lisans aktivasyon ve yönetim</source>
        <translation>License activation and management</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1777"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1782"/>
        <source>🔄 Lisansı Kontrol Et</source>
        <translation>🔄 Check License</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1785"/>
        <source>Lisans durumunu online kontrol et</source>
        <translation>Check your license status online</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1790"/>
        <source>💳 Lisans Satın Al</source>
        <translation>💳 Purchase License</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1793"/>
        <source>Web sitesinden lisans satın al</source>
        <translation>Purchase a license from the website</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1798"/>
        <source>🆓 7 Gün Ücretsiz Dene</source>
        <translation>🆓 7-Day Free Trial</translation>
    </message>
    <message>
        <location filename="../ui/raw/main_window.ui" line="1801"/>
        <source>Trial lisansı başlat</source>
        <translation>Start trial license</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="20"/>
        <source>⚙️ Tercihler</source>
        <translation>⚙️ Preferences</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="48"/>
        <source>🎤 Ses Ayarları</source>
        <translation>🎤 Sound Settings</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="57"/>
        <source>🤖 Whisper Model Ayarları</source>
        <translation>🤖 Whisper Model Settings</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="63"/>
        <source>Model Boyutu:</source>
        <translation>Model Size:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="76"/>
        <source>Küçük model = hızlı ama az doğru, Büyük model = yavaş ama çok doğru</source>
        <translation>Small model = fast but less accurate, Large model = slow but very accurate</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="80"/>
        <source>Tiny (39M) - En Hızlı, Az Doğru</source>
        <translation>Tiny (39M) - Fastest, Least Accurate</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="85"/>
        <source>Base (74M) - Dengeli (Önerilen)</source>
        <translation>Base (74M) - Balanced (Recommended)</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="90"/>
        <source>Small (244M) - Yavaş, Çok Doğru</source>
        <translation>Small (244M) - Slow, Highly Accurate</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="98"/>
        <source>GPU Hızlandırma:</source>
        <translation>GPU Acceleration:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="107"/>
        <source>CUDA GPU kullan (GTX 1050 Ti algılandı)</source>
        <translation>Use CUDA GPU (GTX 1050 Ti detected)</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="119"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;💡 GTX 1050 Ti için Base veya Tiny modeli önerilir&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#fcd535;&quot;&gt;💡 The Base or Tiny model is recommended for the GTX 1050 Ti&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="132"/>
        <source>Wake Word (Uyandırma Kelimesi)</source>
        <translation>Wake Word</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="138"/>
        <source>Uyandırma Kelimesi:</source>
        <translation>Wake Word</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="151"/>
        <source>Whisper</source>
        <translation>Whisper</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="154"/>
        <source>Örnek: Whisper, Vispır, Uyan</source>
        <translation>Exm: Whisper, Vispır</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="161"/>
        <source>Aktif Mod Süresi:</source>
        <translation>Active Mode Duration:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="326"/>
        <source> saniye</source>
        <translation>second</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="192"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Wake word sonrası dinleme süresi&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;Listening time after wake word&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="204"/>
        <source>Mikrofon Ayarları</source>
        <translation>Microphone Settings</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="210"/>
        <source>Mikrofon:</source>
        <translation>Microphone:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="224"/>
        <source>Varsayılan Mikrofon</source>
        <translation>Default Microphone</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="232"/>
        <source>Hassasiyet:</source>
        <translation>Sensitivity:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="263"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;5&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;5&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="278"/>
        <source>Sesli Geri Bildirim</source>
        <translation>Voice Feedback</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="284"/>
        <source>Sesli geri bildirimi aktif et (Text-to-Speech)</source>
        <translation>Enable voice feedback (Text-to-Speech)</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="296"/>
        <source>Konuşma Hızı:</source>
        <translation>Speaking Speed:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="319"/>
        <source>Onay Bekleme Süresi:</source>
        <translation>Approval Pending Period:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="361"/>
        <source>⚠️ Risk Yönetimi</source>
        <translation>⚠️ Risk Management</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="370"/>
        <source>Pozisyon Limitleri</source>
        <translation>Position Limits</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="376"/>
        <source>Maksimum Pozisyon Büyüklüğü:</source>
        <translation>Maximum Position Size:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="990"/>
        <source> USDT</source>
        <translation> USDT</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="402"/>
        <source>Maksimum Kaldıraç:</source>
        <translation>Maximum Leverage:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="923"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="431"/>
        <source>Maksimum Açık Pozisyon Sayısı:</source>
        <translation>Maximum Open Position Count:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="460"/>
        <source>Zarar Limitleri</source>
        <translation>Loss Limits</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="466"/>
        <source>Günlük Kayıp Limiti:</source>
        <translation>Daily Loss Limit:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="494"/>
        <source>veya</source>
        <translation>or</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="604"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="522"/>
        <source>Otomatik Stop Loss:</source>
        <translation>Auto Stop Loss:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="531"/>
        <source>Aktif</source>
        <translation>Active</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="556"/>
        <source>Trailing Stop Aktivasyon:</source>
        <translation>Trailing Stop Activation:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="569"/>
        <source> % kâr sonrası</source>
        <translation> % after profit</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="585"/>
        <source>Slippage Toleransı</source>
        <translation>Slippage Tolerance</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="591"/>
        <source>Maksimum Slippage:</source>
        <translation>Maksimum Slippage:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="637"/>
        <source>🔔 Bildirimler</source>
        <translation>🔔 Notifications</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="646"/>
        <source>Sesli Bildirimler</source>
        <translation>Voice Notifications</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="652"/>
        <source>✅ Pozisyon açıldığında</source>
        <translation>✅ When the position opens</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="662"/>
        <source>🚪 Pozisyon kapandığında</source>
        <translation>🚪 When the position closes</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="672"/>
        <source>🛑 Stop Loss tetiklendiğinde</source>
        <translation>🛑 When the Stop Loss is triggered</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="682"/>
        <source>🎯 Take Profit tetiklendiğinde</source>
        <translation>🎯 When Take Profit is triggered</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="692"/>
        <source>⚠️ Kritik uyarılar</source>
        <translation>⚠️ Critical warnings</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="705"/>
        <source>Desktop Bildirimleri</source>
        <translation>Desktop Notifications</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="711"/>
        <source>Desktop bildirimlerini etkinleştir</source>
        <translation>Enable desktop notifications</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="724"/>
        <source>Uyarı Eşikleri</source>
        <translation>Warning Thresholds</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="730"/>
        <source>Likitasyon Uyarısı:</source>
        <translation>Liquidation Warning:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="743"/>
        <source> % mesafe</source>
        <translation> % distance</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="756"/>
        <source>Marj Oranı Uyarısı:</source>
        <translation>Margin Ratio Warning:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="769"/>
        <source> % altına düşünce</source>
        <translation>falls below</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="785"/>
        <source>Sessiz Saatler</source>
        <translation>Silent Hours</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="797"/>
        <source>Başlangıç:</source>
        <translation>Start:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="837"/>
        <source>HH:mm</source>
        <translation>HH:mm</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="824"/>
        <source>Bitiş:</source>
        <translation>End:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="868"/>
        <source>💹 Trading</source>
        <translation>💹 Trading</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="877"/>
        <source>Varsayılan Ayarlar</source>
        <translation>Default configurations</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="883"/>
        <source>Varsayılan Emir Tipi:</source>
        <translation>Default Order Type:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="897"/>
        <source>Market</source>
        <translation>Market</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="902"/>
        <source>Limit</source>
        <translation>Limit</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="910"/>
        <source>Varsayılan Kaldıraç:</source>
        <translation>Default Leverage:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="939"/>
        <source>Pozisyon Modu:</source>
        <translation>Position Mode:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="953"/>
        <source>One-Way (Tek Yön)</source>
        <translation>One-Way</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="958"/>
        <source>Hedge (Çift Yön)</source>
        <translation>Hedge</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="969"/>
        <source>Paper Trading</source>
        <translation>Paper Trading</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="977"/>
        <source>Başlangıç Bakiyesi:</source>
        <translation>Starting Balance:</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="1014"/>
        <source>🔄 Paper Trading Bakiyesini Sıfırla</source>
        <translation>🔄 Reset Paper Trading Balance</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="1062"/>
        <source>İptal</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../ui/raw/preferences_dialog.ui" line="1075"/>
        <source>💾 Kaydet</source>
        <translation>💾 Save</translation>
    </message>
</context>
<context>
    <name>ReportViewerDialog</name>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="20"/>
        <source>📊 Performans Raporları</source>
        <translation>📊 Performance Reports</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="43"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600; color:#fcd535;&quot;&gt;📈 Trading Performans Raporu&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600; color:#fcd535;&quot;&gt;📈 Trading Performance Report&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="70"/>
        <source>📅 Bugün</source>
        <translation>📅 Today</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="75"/>
        <source>📅 Bu Hafta</source>
        <translation>📅 This Week</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="80"/>
        <source>📅 Bu Ay</source>
        <translation>📅 This Month</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="85"/>
        <source>📅 Tüm Zamanlar</source>
        <translation>📅 All Time</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="105"/>
        <source>Yenile</source>
        <translation>Refresh</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="108"/>
        <source>🔄</source>
        <translation>🔄</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="121"/>
        <source>Export formatı seçin</source>
        <translation>Select export format</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="125"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="130"/>
        <source>Excel</source>
        <translation>Excel</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="135"/>
        <source>CSV</source>
        <translation>CSV</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="140"/>
        <source>JSON</source>
        <translation>JSON</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="154"/>
        <source>📥 Export</source>
        <translation>📥 Export</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="178"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Toplam P&amp;amp;L&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Total P&amp;amp;L&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="185"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#0ecb81;&quot;&gt;+127.50&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600; color:#0ecb81;&quot;&gt;+127.50&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="192"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;USDT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="208"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Win Rate&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Win Rate&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="215"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;62.5&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;62.5&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="222"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;%&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;%&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="238"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Toplam İşlem&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Total Transactions&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;24&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;24&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="252"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;adet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt;item(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Sharpe Ratio&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; color:#848e9c;&quot;&gt;Sharpe Ratio&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;1.45&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;1.45&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:9pt; color:#848e9c;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="298"/>
        <source>📊 Genel Bakış</source>
        <translation>📊 Overview</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="307"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Segoe UI'; font-size:13px; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600; color:#fcd535;&quot;&gt;📈 Performans Özeti&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Rapor verileri burada görüntülenecek...&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kazanan İşlemler:&lt;/span&gt; 15/24 (%62.5)&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ortalama Kazanç:&lt;/span&gt; +12.50 USDT&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ortalama Kayıp:&lt;/span&gt; -8.30 USDT&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Profit Factor:&lt;/span&gt; 2.51&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="324"/>
        <source>📋 İşlem Detayları</source>
        <translation>📋 Transaction Details</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="337"/>
        <source>Zaman</source>
        <translation>Time</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="342"/>
        <source>Sembol</source>
        <translation>Symbol</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="347"/>
        <source>Yön</source>
        <translation>Direction</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="352"/>
        <source>Giriş</source>
        <translation>Entry</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="357"/>
        <source>Çıkış</source>
        <translation>Exit</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="362"/>
        <source>P&amp;L</source>
        <translation>P&amp;L</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="367"/>
        <source>P&amp;L %</source>
        <translation>P&amp;L %</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="372"/>
        <source>Süre</source>
        <translation>Duration</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="381"/>
        <source>📈 Grafikler</source>
        <translation>📈 Charts</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="387"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:14pt; color:#848e9c;&quot;&gt;📊 Performans grafikleri burada görünecek&lt;br/&gt;(Matplotlib/Plotly ile generate edilecek)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:14pt; color:#848e9c;&quot;&gt;📊 Performance graphs will appear here&lt;br/&gt;(Generated with Matplotlib/Plotly)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/raw/report_viewer_dialog.ui" line="422"/>
        <source>Kapat</source>
        <translation>Close</translation>
    </message>
</context>
</TS>
